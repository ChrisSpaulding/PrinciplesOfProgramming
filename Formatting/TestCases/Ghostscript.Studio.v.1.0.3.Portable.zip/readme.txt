Ghostscript Studio presets are added automatically by the installer.

In portable version of Ghostscript Studio presets can be imported from the 'Presets' folder.

Cheers,
Josip Habjan 
habjan@gmail.com
http://www.linkedin.com/in/habjan