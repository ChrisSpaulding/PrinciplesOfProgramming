/* 
Chris Spaulding
Brackets
There is an error on the class, main and for
*/
public class Chris_Brackets {
   public static void main(String[] args){
      for(int i=0;i<10;){
         System.out.println("i");
      }	
   }
}