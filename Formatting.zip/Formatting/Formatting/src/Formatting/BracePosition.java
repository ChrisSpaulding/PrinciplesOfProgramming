
package Formatting;

/**
 *
 * @author chris_000
 */
public class BracePosition {

}
