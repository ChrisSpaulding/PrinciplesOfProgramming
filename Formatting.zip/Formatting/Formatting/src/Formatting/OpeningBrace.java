
package Formatting;

/**
 *
 * @author chris_000
 */
public class OpeningBrace {

    int position; 
    int lineNumber;
    
    
}
